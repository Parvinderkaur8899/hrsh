document.getElementById('themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark');
});